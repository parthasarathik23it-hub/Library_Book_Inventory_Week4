package com.partha.library.service;

import com.partha.library.model.Book;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BookManagerTest {

    private BookManager manager;

    @BeforeEach
    void setUp() {
        manager = new BookManager();
    }

    @Test
    void addBookShouldStoreBook() {
        Book book = new Book("ISBN001", "Clean Code", "Robert Martin", 5);

        manager.addBook(book);

        assertSame(book, manager.findBookByIsbn("ISBN001"));
        assertEquals(1, manager.getBookCount());
    }

    @Test
    void duplicateIsbnShouldBeRejectedIgnoringCase() {
        manager.addBook(new Book("isbn001", "Book One", "Author One", 1));

        assertThrows(IllegalArgumentException.class,
                () -> manager.addBook(new Book("ISBN001", "Book Two", "Author Two", 2)));
    }

    @Test
    void findShouldBeCaseInsensitive() {
        Book book = new Book("ISBN001", "Clean Code", "Robert Martin", 5);
        manager.addBook(book);

        assertSame(book, manager.findBookByIsbn("isbn001"));
    }

    @Test
    void missingBookShouldReturnNull() {
        assertNull(manager.findBookByIsbn("MISSING"));
    }

    @Test
    void updateShouldChangeMutableFields() {
        manager.addBook(new Book("ISBN001", "Old Title", "Old Author", 1));

        manager.updateBook("ISBN001", "New Title", "New Author", 10);

        Book updated = manager.findBookByIsbn("ISBN001");
        assertEquals("New Title", updated.getTitle());
        assertEquals("New Author", updated.getAuthor());
        assertEquals(10, updated.getQuantity());
        assertEquals("ISBN001", updated.getIsbn());
    }

    @Test
    void updateMissingBookShouldThrowException() {
        assertThrows(IllegalArgumentException.class,
                () -> manager.updateBook("MISSING", "Title", "Author", 1));
    }

    @Test
    void deleteShouldRemoveBook() {
        manager.addBook(new Book("ISBN001", "Clean Code", "Robert Martin", 5));

        manager.deleteBook("ISBN001");

        assertNull(manager.findBookByIsbn("ISBN001"));
        assertEquals(0, manager.getBookCount());
    }

    @Test
    void deleteMissingBookShouldThrowException() {
        assertThrows(IllegalArgumentException.class,
                () -> manager.deleteBook("MISSING"));
    }

    @Test
    void inventoryListShouldBeReadOnly() {
        manager.addBook(new Book("ISBN001", "Clean Code", "Robert Martin", 5));

        List<Book> books = manager.getAllBooks();

        assertThrows(UnsupportedOperationException.class,
                () -> books.clear());

        assertEquals(1, manager.getBookCount());
    }

    @Test
    void negativeQuantityShouldBeRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> new Book("ISBN001", "Clean Code", "Robert Martin", -1));
    }

    @Test
    void blankTitleShouldBeRejectedDuringAdd() {
        assertThrows(IllegalArgumentException.class,
                () -> manager.addBook(new Book("ISBN001", " ", "Author", 1)));
    }

    @Test
    void updateShouldPreserveBookCount() {
        manager.addBook(new Book("ISBN001", "Old", "Author", 1));

        manager.updateBook("ISBN001", "New", "Author", 2);

        assertEquals(1, manager.getBookCount());
    }
}
