package com.partha.library.util;

/**
 * Centralizes validation and normalization rules.
 * This avoids repeating the same checks throughout the application.
 */
public final class InputValidator {

    private InputValidator() {
        // Utility class - no object creation required.
    }

    public static String requireText(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be empty.");
        }
        return value.trim();
    }

    public static String normalizeIsbn(String isbn) {
        return requireText(isbn, "ISBN").toUpperCase();
    }

    public static int requireNonNegative(int value, String fieldName) {
        if (value < 0) {
            throw new IllegalArgumentException(fieldName + " cannot be negative.");
        }
        return value;
    }
}
